
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `hotel_szoba`
--

CREATE TABLE `hotel_szoba` (
  `Ar` int(11) DEFAULT NULL,
  `Ferohelyek_szama` int(11) NOT NULL,
  `Parkolas` tinyint(1) NOT NULL,
  `Etkezes` tinyint(1) NOT NULL,
  `Wellnes` int(11) NOT NULL,
  `Szoba_meret` int(11) NOT NULL,
  `SzobaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
