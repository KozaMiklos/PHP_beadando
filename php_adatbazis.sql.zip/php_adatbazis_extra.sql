
--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `felhasználó`
--
ALTER TABLE `felhasználó`
  ADD PRIMARY KEY (`FelhaszID`),
  ADD UNIQUE KEY `felhaszJog` (`felhaszJog`);

--
-- A tábla indexei `hotel_szoba`
--
ALTER TABLE `hotel_szoba`
  ADD PRIMARY KEY (`SzobaID`);
