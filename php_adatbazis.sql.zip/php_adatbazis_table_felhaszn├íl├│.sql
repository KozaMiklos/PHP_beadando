
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasználó`
--

CREATE TABLE `felhasználó` (
  `Nev` varchar(30) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `Cim` varchar(40) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `Telefonszam` int(9) NOT NULL DEFAULT 301234567,
  `Eletkor` int(120) DEFAULT NULL,
  `FelhaszID` int(40) NOT NULL,
  `felhaszJog` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
